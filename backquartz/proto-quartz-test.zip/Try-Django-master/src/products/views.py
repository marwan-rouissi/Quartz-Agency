from django.shortcuts import render, get_object_or_404, redirect
from .forms import ProductForm
from .models import Product
from main.main import main

def product_create_view(request):
    form = ProductForm(request.POST or None)
    
    context = {
        'form': form
    }
    
    return render(request, "products/product_create.html", context)

def product_created_view(request):
    form = ProductForm(request.POST or None)

    strform = str(form)
    listform = [[]]
    for a in strform:
        if a == "\n":
            listform.append("")
        else:
            listform[-1] += a
    prompt = ""
    image_generator = ""
    inPut = [prompt,image_generator]
    n = 0
    for a in listform:
        if "</textarea>" in a:
            inPut[n] = a.replace("</textarea>","")
            n+=1
    textOut,geneImgOut,hashtag = main(inPut[0],inPut[1])        

    context = {
        'prompt':textOut,
        'image_generator':geneImgOut,
        'hashtag':hashtag,
        'form': form

    }
    return render(request, "products/product_created.html", context)


def product_update_view(request, id=id):
    obj = get_object_or_404(Product, id=id)
    form = ProductForm(request.POST or None, instance=obj)
    if form.is_valid():
        form.save()
    context = {
        'form': form
    }
    return render(request, "products/product_create.html", context)


def product_list_view(request):
    queryset = Product.objects.all() # list of objects
    context = {
        "object_list": queryset
    }
    return render(request, "products/product_list.html", context)

def product_detail_view(request, id):
    obj = get_object_or_404(Product, id=id)
    context = {
        "object": obj
    }
    return render(request, "products/product_detail.html", context)


def product_delete_view(request, id):
    obj = get_object_or_404(Product, id=id)
    if request.method == "POST":
        obj.delete()
        return redirect('../../')
    context = {
        "object": obj
    }
    return render(request, "products/product_delete.html", context)
