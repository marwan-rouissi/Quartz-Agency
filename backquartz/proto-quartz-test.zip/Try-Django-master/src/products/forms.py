from django import forms

from .models import Product

from main.main import main

class ProductForm(forms.ModelForm):
    prompt       = forms.CharField(required=False, 
                        widget=forms.Textarea(attrs={
                                    "placeholder": "put your article subject",
                                    "class": "new-class-name two",
                                    "id": "my-id-for-textarea",
                                    "rows": 8,
                                    'cols': 50}))
    image_generator   = forms.CharField(
                        required=False, 
                        widget=forms.Textarea(
                                attrs={
                                    "placeholder": "If you want some images, fills this blank",
                                    "class": "new-class-name two",
                                    "id": "my-id-for-textarea",
                                    "rows": 5,
                                    'cols': 45
                                }
                            )
                        )
    
    class Meta:
        model = Product
        fields = [
            'prompt',
            'image_generator'
        ]


class RawProductForm(forms.Form):
    prompt       = forms.CharField(required=False, 
                        widget=forms.Textarea(
                                attrs={
                                    "placeholder": "Your description",
                                    "class": "new-class-name two",
                                    "id": "my-id-for-textarea",
                                    "rows": 20,
                                    'cols': 120
                                }
                            )
                        )
    imgKeyWord   = forms.CharField(
                        required=False, 
                        widget=forms.Textarea(
                                attrs={
                                    "placeholder": "Your description",
                                    "class": "new-class-name two",
                                    "id": "my-id-for-textarea",
                                    "rows": 20,
                                    'cols': 120
                                }
                            )
                        )